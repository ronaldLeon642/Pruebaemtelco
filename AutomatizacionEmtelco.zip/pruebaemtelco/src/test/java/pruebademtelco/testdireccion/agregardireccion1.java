package pruebademtelco.testdireccion;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;


public class agregardireccion1 {

public static void main(String[] args) {
	
	
    // ruta controlador y creacion de instancia mozila o chrome// 
	//para ejecutar el script favor tener en cuanta cambira la ruta del controlador 
	//System.setProperty("webdriver.chrome.driver","C:\\Users\\ronald\\Desktop\\chromedriver.exe");

	System.setProperty("webdriver.gecko.driver","C:\\Users\\ronald\\Desktop\\geckodriver.exe");
	
	WebDriver driver = new FirefoxDriver();

	//WebDriver driver = new ChromeDriver() ;
	//ingreso pagina principal
    String baseUrl = "http://automationpractice.com/index.php";
    driver.get(baseUrl);
    //ingreso modulo logueo
    driver.findElement(By.className("login")).click();
    //ingresa datos de user previamente creado e ingresa
    driver.findElement(By.id("email")).sendKeys("ronaldprogramando@gmail.com");
    driver.findElement(By.id("passwd")).sendKeys("golden");
    driver.findElement(By.id("SubmitLogin")).click();
    //ingresa opcion My Addresses    
    driver.findElement(By.className("icon-building")).click();
    //click boton agregar nueva direccion
    driver.findElement(By.xpath("/html/body/div[1]/div[2]/div/div[3]/div/div[2]/a/span")).click();
    //click datos al formulario de crear direccion
    driver.findElement(By.id("address1")).sendKeys("golden");
    driver.findElement(By.id("address2")).sendKeys("golden");
    driver.findElement(By.id("city")).sendKeys("golden");    
    Select estado = new Select (driver.findElement(By.id("id_state")));
    estado.selectByVisibleText("Alabama");
    driver.findElement(By.id("postcode")).sendKeys("11111");
    Select pais = new Select (driver.findElement(By.id("id_country")));
    pais.selectByVisibleText("United States");
    driver.findElement(By.id("phone")).sendKeys("3206083527");    
    driver.findElement(By.id("phone_mobile")).sendKeys("3206083528");
    driver.findElement(By.id("other")).sendKeys("golden1234211((///");
    driver.findElement(By.id("alias")).clear();
    driver.findElement(By.id("alias")).sendKeys("pruebadireccion");
    //click envia formulario creacion de direccion
    driver.findElement(By.id("submitAddress")).click();    
    driver.findElement(By.id("my-account")).click();
    //se debe crear y adicionar la direccion "pruebadireccion"
    driver.close();
    System.exit(0);

    
          
    
    	
		
	}}	

